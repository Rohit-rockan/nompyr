# Removed AnimeVerse scraper
